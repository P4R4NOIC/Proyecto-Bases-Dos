import { Client } from 'cassandra-driver';

const client = new Client({
  contactPoints: ['localhost'], // Cambia esto si Cassandra está en un host diferente
  localDataCenter: 'datacenter1',
  keyspace: 'tec_digital', // Cambia esto al nombre de tu keyspace
});

export default client ;


