import Redis from 'ioredis';

const redis = new Redis({
  host: 'localhost', // Cambia esto al host de tu servidor Redis
  port: 6379,        // Cambia esto al puerto de tu servidor Redis
});
export default redis;