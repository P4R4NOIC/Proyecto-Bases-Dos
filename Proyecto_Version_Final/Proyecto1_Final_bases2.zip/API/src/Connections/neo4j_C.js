import { driver as _driver, auth } from 'neo4j-driver';

const driver = _driver('bolt://localhost:7687', auth.basic('neo4j', 'password'));
const session = driver.session();

export default session;