import { DocumentStore } from 'ravendb';

const ravenDBConfig = new DocumentStore(
   'http://localhost:8080', // Pasa la URL directamente como una cadena
  'TECDIGITAL'
);

try {
    await ravenDBConfig.initialize();
    console.log('Conexión a RavenDB establecida con éxito.');
} catch (error) {
    console.error('Error al conectar a RavenDB:', error);
}

export default ravenDBConfig;
