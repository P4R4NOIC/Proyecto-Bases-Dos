import express from "express";
import cors from "cors";
import body_Parser from "body-parser";
import ravenDBConfig from './Connections/raven_C.js'; // Ruta relativa desde el directorio actual
import cassandraDBConfig from './Connections/cassandra_C.js'; 
import neo4j, { session } from 'neo4j-driver';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const driver = neo4j.driver(
    'bolt://localhost:7999', 
    neo4j.auth.basic('neo4j', 'password'),
);
const uuid = uuidv4();
app.use(body_Parser.json());
app.use(cors());
app.use(express.json({
    type: "*/*"
}))
app.use(
    express.urlencoded({
      extended: true
    })
)

import  redis from './Connections/redis_C.js';

//Recuperar la lista de todos los usuarios 

app.get('/Todos-Usuarios', async (req, res) => {
    const query = 'SELECT * FROM usuarios';

    try {
        const resultado = await cassandraDBConfig.execute(query);
        const usuarios = resultado.rows;
       
        res.json(usuarios);
    } catch (error) {
        console.error('Error al recuperar usuarios: ', error);
        res.status(500).json({ error: 'Error al recuperar usuarios' });
    }
});


app.get('/Todos-Profes', async (req, res) => {
    const query = 'SELECT * FROM Profesores';

    try {
        const resultado = await cassandraDBConfig.execute(query);
        const usuarios = resultado.rows;
        
        res.json(usuarios);
    } catch (error) {
        console.error('Error al recuperar usuarios: ', error);
        res.status(500).json({ error: 'Error al recuperar usuarios' });
    }
});


app.get('/MateriasMatriculadas/:Username', async (req, res) => {
    const userId = req.params.Username; 
    
    const query = 'SELECT * FROM cursos_por_usuario  WHERE username = ? ALLOW FILTERING'; 

    try {
        const resultado = await cassandraDBConfig.execute(query, [userId]); 
        const usuario = resultado.rows; // Suponiendo que solo obtendrás un usuario
        
        if (usuario) {
            res.json(usuario); // Si se encuentra el usuario, envía su información como respuesta JSON
        } else {
            res.status(404).json({ error: 'Usuario no encontrado' }); // Si no se encuentra el usuario, responde con un código 404
        }
    } catch (error) {
        console.error('Error al recuperar usuario: ', error);
        res.status(500).json({ error: 'Error al recuperar usuario' });
    }
});

//Ejemplo de prueba con redis 

app.get('/RedisMensajesdeHoy/:llave', async (req, res) => {
    const key = req.params.llave; // Reemplaza 'miClave' con la clave que deseas recuperar de Redis

    try {
        const data = await redis.get(key); // Usamos redis.get para obtener el valor asociado a la clave
        
        if (data) {
            // Si se encuentra el valor en Redis, lo enviamos como respuesta JSON
            res.json(data); // Asumiendo que el valor en Redis es una cadena JSON
        } else {
            res.status(404).json({ error: 'Clave no encontrada en Redis' });
        }
    } catch (error) {
        console.error('Error al recuperar datos de Redis: ', error);
        res.status(500).json({ error: 'Error al recuperar datos de Redis' });
    }
})

//Recuperar un informacion de un usuario
app.get('/Usuario/:Username', async (req, res) => {
    const userId = req.params.Username; 
    console.log(userId);
    const query = 'SELECT * FROM usuarios WHERE username = ?'; 

    try {
        const resultado = await cassandraDBConfig.execute(query, [userId]); 
        const usuario = resultado.rows[0]; // Suponiendo que solo obtendrás un usuario
        

        if (usuario) {
            res.json(usuario); // Si se encuentra el usuario, envía su información como respuesta JSON
        } else {
            res.status(404).json({ error: 'Usuario no encontrado' }); // Si no se encuentra el usuario, responde con un código 404
        }
    } catch (error) {
        console.error('Error al recuperar usuario: ', error);
        res.status(500).json({ error: 'Error al recuperar usuario' });
    }
});
app.get('/recuperarCurso/:Username', async (req, res) => {
  const userId = req.params.Username; 
  console.log(userId);
  const query = 'SELECT * FROM cursos WHERE codigo = ?'; 

  try {
      const resultado = await cassandraDBConfig.execute(query, [userId]); 
      const usuario = resultado.rows[0]; // Suponiendo que solo obtendrás un usuario
      

      if (usuario) {
          res.json(usuario); // Si se encuentra el usuario, envía su información como respuesta JSON
      } else {
          res.status(404).json({ error: 'Usuario no encontrado' }); // Si no se encuentra el usuario, responde con un código 404
      }
  } catch (error) {
      console.error('Error al recuperar usuario: ', error);
      res.status(500).json({ error: 'Error al recuperar usuario' });
  }
});
// Recuperar un profesor
app.get('/Profesor/:Username', async (req, res) => {
    const userId = req.params.Username; 
    console.log(userId);
    const query = 'SELECT * FROM profesores WHERE username = ?'; 

    try {
        const resultado = await cassandraDBConfig.execute(query, [userId]); 
        const usuario = resultado.rows[0]; // Suponiendo que solo obtendrás un usuario
        

        if (usuario) {
            res.json(usuario); // Si se encuentra el usuario, envía su información como respuesta JSON
        } else {
            res.status(404).json({ error: 'Usuario no encontrado' }); // Si no se encuentra el usuario, responde con un código 404
        }
    } catch (error) {
        console.error('Error al recuperar usuario: ', error);
        res.status(500).json({ error: 'Error al recuperar usuario' });
    }
});
//Recuperar cursos de un profesor 
app.get('/CursosProfesor/:Username', async (req, res) => {
    const userId = req.params.Username; 
    
    const query = 'SELECT * FROM cursos_por_profesor WHERE codigo_profesor = ? ALLOW FILTERING'; 

    try {
        const resultado = await cassandraDBConfig.execute(query, [userId]); 
        const usuario = resultado.rows; // Suponiendo que solo obtendrás un usuario
        

        if (usuario) {
            res.json(usuario); // Si se encuentra el usuario, envía su información como respuesta JSON
        } else {
            res.status(404).json({ error: 'Cursos no encontrados' }); // Si no se encuentra el usuario, responde con un código 404
        }
    } catch (error) {
        console.error('Error al recuperar Cursos: ', error);
        res.status(500).json({ error: 'Error al recuperar usuario' });
    }
});


app.get('/consultarCorreosEnviados/:username', async (req, res) => {
    const session = ravenDBConfig.openSession();
    const username=req.params.username;
    
    try {
      // Realizar la consulta
      const resultados = await session.query({
        collection: 'Correos'}).whereEquals('idRemitente', username).all();
      
      console.log(resultados);
      res.json(resultados);
    } catch (error) {
      console.error('Error en la consulta de correos:', error);
      res.status(500).json({ error: 'Error en la consulta de correos' });
    } finally {
      session.dispose();
    }
  });

app.get('/consultarEvaluaciones/:username', async (req, res) => {
    const session = ravenDBConfig.openSession();
    const username = req.params.username
    
    try {
      // Realizar la consulta
      const resultados = await session.query({
        collection: 'evaluacion'}).whereEquals('idCurso', username).all();
      
      console.log(resultados);
      res.json(resultados);
    } catch (error) {
      console.error('Error en la consulta de correos:', error);
      res.status(500).json({ error: 'Error en la consulta de correos' });
    } finally {
      session.dispose();
    }
  });

app.get('/consultarNotasEstudiante/:codigoCurso/:CodigoUsuario', async (req, res) => {
    const session = ravenDBConfig.openSession();
    const coleccion = req.params.coleccion;
    const userid = req.params.CodigoUsuario;
    const codigocurso=req.params.codigoCurso;
    
    try {
      // Realizar la consulta
      const resultados = await session.query({
        collection: 'Notas'}).whereEquals("codigoUsuario", userid)
        .andAlso()
        .whereEquals('codigoCurso', codigocurso)
        .all();
      
      console.log(resultados);
      res.json(resultados);
    } catch (error) {
      console.error('Error en la consulta de correos:', error);
      res.status(500).json({ error: 'Error en la consulta de correos' });
    } finally {
      session.dispose();
    }
  });

app.get('/consultarPreguntas/:username', async (req, res) => {
    const session = ravenDBConfig.openSession();
    const username = req.params.username
    
    try {
      // Realizar la consulta
      const resultados = await session.query({
        collection: 'preguntas'}).whereEquals('idEvaluacion', username).all();
      
      
      res.json(resultados);
    } catch (error) {
      console.error('Error en la consulta de correos:', error);
      res.status(500).json({ error: 'Error en la consulta de correos' });
    } finally {
      session.dispose();
    }
  });

app.get('/consultarCorreosRecibidos/:username', async (req, res) => {
    const session = ravenDBConfig.openSession();
    const username=req.params.username;
    
    try {
      // Realizar la consulta
      const resultados = await session.query({
        collection: 'Correos'}).whereEquals('idDestinatario', username).all();
       
        
        
        console.log(resultados);
      
      res.json(resultados);
    } catch (error) {
      console.error('Error en la consulta de correos:', error);
      res.status(500).json({ error: 'Error en la consulta de correos' });
    } finally {
      session.dispose();
    }
  });
app.get('/buscarAmigos/:username', async (req, res)=> {
    let user1 = req.params.username;
    const session = driver.session();
    const query1 = `
    MATCH (:User {username:'${user1}'})-[:FRIEND]->(friendsUser) 
    RETURN friendsUser
    `;
  
    try{
      const response = await session.run(query1,
      {user1});
    
      const friendsNodes = response.records.map(record => record.get('friendsUser').properties);
      res.status(200).json(friendsNodes);
    } catch (error) {
      console.error("error al buscar amigos", error);
      res.status(500).json({error: "An error person info"});
    } finally{
        session.close();
    }
  })
  
app.get('/consultarMatricula/:Username', async (req, res) => {
    const userId = req.params.Username; 
    
    const query = 'SELECT * FROM cursos_por_usuario WHERE username = ? ALLOW FILTERING';
    const query2 ='SELECT * FROM cursos WHERE estado = ? AND fechainit > ? ALLOW FILTERING'; 
    
    const fecha = new Date();
    const año = fecha.getFullYear();
    const mes = (fecha.getMonth() + 1).toString().padStart(2, '0');
    const dia = fecha.getDate().toString().padStart(2, '0');

    const fechaFormateada = `${año}-${mes}-${dia}`;
    

    try {
        const cursosMatriculados = new Set();
        const resultado = [];

        const listaCursosM = await cassandraDBConfig.execute(query, [userId]);
        const listaCursosD = await cassandraDBConfig.execute(query2, ['Disponible', fechaFormateada]);

        // Agregar códigos de cursos matriculados al conjunto
        listaCursosM.rows.forEach((curso) => {
            cursosMatriculados.add(curso.codigo);
        });

        // Filtrar cursos disponibles y no matriculados
        listaCursosD.rows.forEach((cursoM) => {
            if (!cursosMatriculados.has(cursoM.codigo)) {
                resultado.push(cursoM);
            }
        });

        

        if (resultado.length > 0) {
            res.json(resultado); // Si se encuentran cursos, envía su información como respuesta JSON
        } else {
            res.status(404).json({ error: 'Cursos no encontrados' }); // Si no se encuentran cursos, responde con un código 404
        }
    } catch (error) {
        console.error('Error al recuperar usuario: ', error);
        res.status(500).json({ error: 'Error al recuperar usuario' });
    }
});
app.get('/consultarSeccionesCurso/:username', async (req, res) => {
  const session = ravenDBConfig.openSession();
  const username=req.params.username;
  
  try {
    // Realizar la consulta
    const resultados = await session.query({
      collection: 'Seccion'}).whereEquals('idCurso', username).all();
     
      
      
      
    
    res.json(resultados);
  } catch (error) {
    console.error('Error en la consulta de correos:', error);
    res.status(500).json({ error: 'Error en la consulta de correos' });
  } finally {
    session.dispose();
  }
});
app.get('/consultarEstudiantesCurso/:Username', async (req, res) => {
  const userId = req.params.Username; 
  const query = 'SELECT * FROM cursos_por_usuario WHERE codigo = ? ALLOW FILTERING';

  try {
    const listaEstudiantes = await cassandraDBConfig.execute(query, [userId]);

    if (!listaEstudiantes.length) {
      const query2 = 'SELECT * FROM usuarios WHERE username = ?';
      const resultado = [];

      for (const estudiante of listaEstudiantes.rows) {
        const username = estudiante.username;
        const infoUsuario = await cassandraDBConfig.execute(query2, [username]); 
        resultado.push(infoUsuario.rows);
      }

      console.log(resultado);
      res.json(resultado);
    } else {
      res.status(404).json({ error: 'Cursos no encontrados' });
    }
  } catch (error) {
    console.error('Error al recuperar usuario: ', error);
    res.status(500).json({ error: 'Error al recuperar usuario' });
  }
});






//////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////

//Posts

//Recuperar un informacion de un usuario
app.post('/RegistrarEstudiante', async (req, res) => {
  let username = req.body.usuario;
  const session = driver.session();
  try {
      const { usuario, contrasena, fecNac, img, primNombre, primApellido, salt, segApellido, segNombre } = req.body;
      const query = 'INSERT INTO Usuarios (Username, Contra, fechaNacimiento, foto, nombre, primerapellido, salt, segundoapellido, segundonombre) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
      const query1 = `CREATE (:User {username: '${username}'})`;

      // Valida que se proporcionen las propiedades "nombre" y "email"
      if (!usuario || !contrasena) {
          return res.status(400).json({ error: 'Datos incompletos' });
      }
      await cassandraDBConfig.execute(query, [usuario, contrasena, fecNac, img, primNombre, primApellido, salt, segApellido, segNombre]);
      await session.run(query1,
        {username});

      res.status(201).json({ message: 'Usuario insertado con éxito' });
  } catch (error) {
    console.error('Error al insertar usuario: ', error);
    res.status(500).json({ error: 'Error al insertar usuario' });
  } finally {
    session.close();
  }

});
//Recuperar un informacion de un usuario
app.post('/RegistrarProfesor', async (req, res) => {
  let username = req.body.usuario;
  const session = driver.session();
  try {
      
      const { usuario, contrasena, fecNac, img, primNombre, primApellido, salt, segApellido, segNombre } = req.body;
      
      const query = 'INSERT INTO profesores (Username, Contra, fechaNacimiento, foto, nombre, primerapellido, salt, segundoapellido, segundonombre) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
      const query1 = `CREATE (:User {username: '${username}'})`;

      // Valida que se proporcionen las propiedades "nombre" y "email"
      
      if (!usuario|| !contrasena) {
          return res.status(400).json({ error: 'Datos incompletos' });
      }
      await cassandraDBConfig.execute(query, [usuario, contrasena, fecNac, img, primNombre, primApellido, salt, segApellido, segNombre]);
      await session.run(query1, {username});


      res.status(201).json({ message: 'Usuario insertado con éxito' });
  } catch (error) {
    console.error('Error al insertar usuario: ', error);
    res.status(500).json({ error: 'Error al insertar usuario' });
  }
});
//Registrar cursos a la tabla general
app.post('/RegistrarCurso', async (req, res) => {
    try {
        const { codigo, fechainit, fechafinal, descripcion, estado, foto, nombre } = req.body;
        const query = 'INSERT INTO Cursos (codigo, fechainit, fechafinal, descripcion, estado, foto, nombre) VALUES (?, ?, ?, ?, ?, ?, ?)';
        
        // Valida que se proporcionen las propiedades "nombre" y "email"
        if (!codigo|| !fechainit) {
            return res.status(400).json({ error: 'Datos incompletos' });
        }
        await cassandraDBConfig.execute(query, [codigo, fechainit, fechafinal, descripcion, estado, foto, nombre ]);
    

        res.status(201).json({ message: 'Curso insertado con éxito' });
    } catch (error) {
      console.error('Error al insertar Curso: ', error);
      res.status(500).json({ error: 'Error al insertar Curso' });
    }
});

//Registra un curso creado por el profesor
app.post('/RegistrarCursoProfesor', async (req, res) => {
    try {
        const { codigo_curso ,codigo_profesor ,descripcion ,estado,fechafinal ,fechainit,foto,nombre } = req.body;
        const query = 'INSERT INTO cursos_por_profesor (codigo_curso ,codigo_profesor ,descripcion ,estado,fechafinal ,fechainit,foto,nombre) VALUES (?, ?, ?, ?, ?, ?, ?,?)';
        
        // Valida que se proporcionen las propiedades "nombre" y "email"
        if (!codigo_profesor|| !codigo_curso) {
            return res.status(400).json({ error: 'Datos incompletos' });
        }
        await cassandraDBConfig.execute(query, [codigo_curso ,codigo_profesor,descripcion ,estado,fechafinal ,fechainit,foto,nombre ]);
    

        res.status(201).json({ message: 'Curso insertado con éxito' });
    } catch (error) {
      console.error('Error al insertar Curso: ', error);
      res.status(500).json({ error: 'Error al insertar Curso' });
    }
});
//Registrar Seccion 
app.post('/GuardarDocumento/:coleccion', async (req,res)=>{
    const ravenDB = ravenDBConfig.openSession();
    const seccion = req.body;
    const coleccion = req.params.coleccion;
    seccion['@metadata']={'@collection':coleccion};
    try{
        
        await ravenDB.store(seccion);
        await ravenDB.saveChanges();
        res.status(201).json({ mensaje: 'Documento guardado exitosamente' });
    }catch (error){
        console.error('Error al guardar el documento:', error);
        res.status(500).json({ error: 'Error al guardar el documento' });
    }finally{
        ravenDB.dispose();
    }
});
app.post('/anadirAmigos', async (req, res)=> {
    let user1 = req.body.username1;
    let user2 = req.body.username2;
    
    const session = driver.session();
    const query = `
      MATCH (p1:User {username: '${user1}'})
      MATCH (p2:User {username: '${user2}'})
      CREATE (p1)-[:FRIEND]->(p2)
    `;
    try {
      const response = await session.run(
        query, {user1, user2});
  
     } catch (error) {
      console.error("error al anadir amigos", error);
      res.status(500).json({error: "An error  anadiendo amigos"});
    } finally{
        session.close();
    }
  
   
    
  })
app.post('/registrarUsuario', async (req, res)=> {
    let username = req.body.username;
    let nombre = req.body.nombre;
    let segundonombre = req.body.nombresegundo;
    let primerapellido = req.body.primerapellido;
    let segundoapellido = req.body.segundoapellido;
    const session = driver.session();
    const query = `CREATE (:User {username: '${username}', nombre: '${nombre}',
    nombresegundo: '${segundonombre}', primerapellido: '${primerapellido}', segundoapellido: '${segundoapellido}'})`;
  
    try{
      const response = await session.run(query,
      {username, nombre, segundonombre, primerapellido, segundoapellido});
      res.json({ message: 'User created' });
    } catch (error){
      console.error(error);
  
      return{
        statusCode: 500,
        body: JSON.stringify({error: "An error creating user"} , null, 2),
      }
    } finally {
      session.close();
    }
  
})

app.post('/eliminarAmigos', async (req, res)=> {
    let user1 = req.body.username1;
    let user2 = req.body.username2;
    
    const session = driver.session();
    const query = `
      MATCH (p1:User {username: '${user1}'})
      MATCH (p2:User {username: '${user2}'})
      MATCH (p1)-[r]->(p2)
      DELETE r
    `;
    try {
      const response = await session.run(
        query, {user1, user2});
  
     } catch (error) {
      console.error("error al eliminar amigos", error);
      res.status(500).json({error: "An error eliminar amigos"});
    } finally{
        session.close();
    }
  
   
    
})
app.post('/RegistrarCursoEstudiante', async (req, res) => {
    try {

        const { username ,codigo ,descripcion ,estado,fechafinal ,fechainit,foto,nombre } = req.body;
        const idUnico = uuidv4();
        
        const query = 'INSERT INTO cursos_por_usuario(id_matricula,codigo ,descripcion ,estado ,fechafinal,fechainit ,foto,nombre,username) VALUES (?,?, ?, ?, ?, ?, ?, ?,?)';
        
        // Valida que se proporcionen las propiedades "nombre" y "email"
        if (!username|| !codigo) {
            return res.status(400).json({ error: 'Datos incompletos' });
        }
        await cassandraDBConfig.execute(query, [idUnico,codigo ,descripcion ,estado ,fechafinal,fechainit ,foto,nombre,username ]);
    

        res.status(201).json({ message: 'Curso insertado con éxito' });
    } catch (error) {
      console.error('Error al insertar Curso: ', error);
      res.status(500).json({ error: 'Error al insertar Curso' });
    }
});

app.post('/CrearModificarSeccion/', async (req, res) => {
  // Los datos del curso se esperan en el cuerpo de la solicitud
  const cursoData = req.body;
  const codigoCurso = cursoData.idCurso;
  cursoData['@metadata']={'@collection':'Seccion'};
  const ravenDB = ravenDBConfig.openSession();
  try {
      

      

      // Verifica si el documento ya existe en la base de datos
      const cursoExistente = await ravenDB.load(codigoCurso);

      if (cursoExistente) {
          // El documento ya existe, puedes manejarlo como desees, como devolver un mensaje de error
          await ravenDB.store(cursoData,codigoCurso);
          await ravenDB.saveChanges();
          res.status(201).json({ message: 'La seccion del curso ya existe se ha modificado' });
      } else {
          // El documento no existe, puedes crearlo
          await ravenDB.store(cursoData);
          await ravenDB.saveChanges();

          res.status(201).json({ message: 'Curso insertado con éxito' });
      }
  } catch (error) {
      console.error('Error al insertar o verificar el curso: ', error);
      res.status(500).json({ error: 'Error al insertar o verificar el curso' });
  }finally{
    ravenDB.dispose();
}
});



app.post('/ClonarCurso/:curso/:cursoNuevo', async (req, res) => {
  const ravenDB = ravenDBConfig.openSession();
  try {
    const codigo_base = req.params.curso;
    const codigo_nuevo = req.params.cursoNuevo;

    // Realiza una consulta para obtener la sección que deseas clonar
    const seccionOriginal = await ravenDB.query({
      collection: 'Seccion'
    }).whereEquals('idCurso', codigo_base).firstOrNull();

    if (seccionOriginal) {
      // Genera un nuevo ID único para la sección clonada
      const nuevoId = uuidv4();

      // Copia los valores de la sección original a la nueva sección
      const nuevaSeccion = { ...seccionOriginal };
      nuevaSeccion.idCurso = codigo_nuevo; // Cambia el valor del atributo idCurso
      nuevaSeccion.id = nuevoId; // Cambia el ID autogenerado por RavenDB

      // Almacena la nueva sección en la base de datos
      await ravenDB.store(nuevaSeccion);
      await ravenDB.saveChanges();

      res.status(201).json({ message: 'Sección clonada con éxito', newId: nuevoId });
    } else {
      res.status(404).json({ error: 'Sección no encontrada' });
    }
  } catch (error) {
    console.error('Error al clonar la sección: ', error);
    res.status(500).json({ error: 'Error al clonar la sección' });
  } finally {
    ravenDB.dispose();
  }
});





app.listen(3000);
console.log('Server on port', 3000);
