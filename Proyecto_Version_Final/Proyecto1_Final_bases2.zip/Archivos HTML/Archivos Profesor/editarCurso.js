
function cargarPagina(){
    //FUNCION DE AUTENTICACION DE USUARIO
    autenticar()
    let usuarioJSON = localStorage.getItem("usuario");
    var usuario = JSON.parse(usuarioJSON);
    var nombre = usuario.nombre;
    document.getElementById("nombreProfesor").textContent = nombre;
    
    
    recuperaCurso();
    //CARGA LA PAGINA CUANDO TODO ESTA LISTO
    document.addEventListener("DOMContentLoaded", cargarPagina);
}

function recuperaCurso(){
    var cursoActual = localStorage.getItem("codigoCursoActual");
    console.log(localStorage.getItem("codigoCursoActual"))
    let datosRecibidos;
    // Hacer la solicitud GET al servidor
    fetch('http://localhost:3000/recuperarCurso/'+cursoActual)
    .then(response => {
        if (!response.ok) {
            alert('No se pudo obtener la informaci贸n del usuario');
        }
        return response.json(); // Parsea la respuesta JSON
    })
    .then(data => {
        // Datos recibidos
        datosRecibidos = data;
        
        localStorage.setItem("objetoCursoActual", JSON.stringify(datosRecibidos))
        generarPagina();

    })
    .catch(error => {
        console.error('Error al obtener la informaci贸n del usuario:', error);
    });
}

function generarPagina(){
    let cursoActual = JSON.parse(localStorage.getItem("objetoCursoActual"));
    console.log(cursoActual)
    let inputUsuario = document.getElementById("codigoCurso");
    inputUsuario.placeholder = localStorage.getItem("usuario");
    inputUsuario.required = false;
    inputUsuario.readOnly = true;

    document.getElementById("codigoCurso").value = cursoActual.codigo;
    document.getElementById("nombreCurso").value = cursoActual.nombre;
    document.getElementById("desCurso").value = cursoActual.descripcion;
    document.getElementById("cursoInicio").value = cursoActual.fechainit;
    document.getElementById("cursoFin").value = cursoActual.fechafinal;
    document.getElementById("estadoCurso").value = cursoActual.estado;
    
}

document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.getElementById("formulario");

    formulario.addEventListener ("submit", function(event) {
        //EVITA QUE SE ENVIE
        event.preventDefault();
        
        let codigoCurso = document.getElementById("codigoCurso").value;
        let nombreCurso = document.getElementById("nombreCurso").value;
        let desCurso = document.getElementById("desCurso").value;
        let cursoInicio = document.getElementById("cursoInicio").value;
        let cursoFin = document.getElementById("cursoFin").value;
        let estadoCurso = document.getElementById("estadoCurso").value;
        let foto = document.getElementById("myImg").value;
        if (document.getElementById("estadoCurso").selectedIndex == 0) {
            alert('Por favor, seleccione un curso antes de enviar el formulario.');
        }else{
            let datosUsuario = {
                codigo: codigoCurso,
                fechainit: cursoInicio,
                fechafinal: cursoFin,
                descripcion: desCurso,
                estado: estadoCurso,
                foto: foto,
                nombre: nombreCurso
            };
            let usuarioJSON = localStorage.getItem("usuario");
            var usuario = JSON.parse(usuarioJSON);
            var nombreUsuario = usuario.username;
            
            
            let cursoParaProfe = {
                codigo_profesor: nombreUsuario,
                codigo_curso: codigoCurso,
                descripcion: desCurso,
                estado: estadoCurso,
                fechafinal: cursoFin,
                fechainit: cursoInicio,
                foto: foto,
                nombre: nombreCurso
            };
            let datosUsuarioJSON = JSON.stringify(datosUsuario);
            let cursoParaProfeJSON = JSON.stringify(cursoParaProfe);
            subirDatosCurso(datosUsuarioJSON);
            registrarCursoParaUnProfe(cursoParaProfeJSON);
            alert("Su curso ha sido actualizado con éxito.");
        }
        
    })
});

function subirDatosCurso(datos){
    fetch('http://localhost:3000/RegistrarCurso', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: datos
    })
}

function registrarCursoParaUnProfe(datos){
    fetch('http://localhost:3000/RegistrarCursoProfesor', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: datos
    })
}