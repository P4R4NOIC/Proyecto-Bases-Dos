function cargarPagina(){
    //FUNCION DE AUTENTICACION DE USUARIO
    autenticar()
    let usuarioJSON = localStorage.getItem("usuario");
    var usuario = JSON.parse(usuarioJSON);
    var nombre = usuario.nombre;
  
    document.getElementById("nombreProfesor").textContent = nombre;
    cargarPersonas()
    //CARGA LA PAGINA CUANDO TODO ESTA LISTO
    document.addEventListener("DOMContentLoaded", cargarPagina);
}

function cargarPersonas(){
    var cursoActual = localStorage.getItem("codigoCursoActual");
    console.log(localStorage.getItem("codigoCursoActual"))
    let datosRecibidos;
    // Hacer la solicitud GET al servidor
    fetch('http://localhost:3000/consultarEstudiantesCurso/'+cursoActual)
    .then(response => {
        if (!response.ok) {
            alert('No se pudo obtener la informaci贸n del usuario');
        }
        return response.json(); // Parsea la respuesta JSON
    })
    .then(data => {
        // Datos recibidos
        datosRecibidos = data;
        
        localStorage.setItem("listaPersonasEnCurso", JSON.stringify(datosRecibidos))
        imprimirPersonas();

    })
    .catch(error => {
        console.error('Error al obtener la informaci贸n del usuario:', error);
    });
}

function imprimirPersonas(){
    
    personas = JSON.parse(localStorage.getItem("listaPersonasEnCurso"));
    for (i = 0; i < personas.length; i++) {
     
        crearLista(personas,i);
    }
    
}

function crearLista(personas, i){
    //CREA UNA FILA
    console.log(personas[i])
    var fila = document.createElement("tr"); 

    //CREA LA PRIMERA COLUMNA
    var columnaApellido = document.createElement("td"); 
    columnaApellido.innerHTML = personas[i][0]["primerapellido"] + " " + personas[i][0]["segundoapellido"]
  
    fila.appendChild(columnaApellido);

    //CREA LA SEGUNDA COLUMNA
    var columnaNombre = document.createElement("td"); 
    columnaNombre.innerHTML = personas[i][0]["nombre"] + " " + personas[i][0]["segundonombre"];
    fila.appendChild(columnaNombre);

    //CREA LA TERCERA COLUMNA
    var columnaCorreo = document.createElement("td"); 
    columnaCorreo.innerHTML = personas[i][0]["username"];
    fila.appendChild(columnaCorreo);

    //AGREGA AL TBODY
    document.querySelector(".cuerpoTabla").appendChild(fila);
}